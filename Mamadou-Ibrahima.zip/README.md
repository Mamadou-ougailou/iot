To use the val.py you have to install python3 and the package: jsonschema 
pip3 install jsonschema
Put your json into a file named test.json
You can then run the validator with the command: python3 val.py test.json
Example: python3 val.py ./test.json